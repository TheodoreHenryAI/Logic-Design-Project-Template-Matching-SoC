`timescale 1ns/1ps

module tb_SAD_calc;
    reg clk = 0, rst_n = 0, start = 0;
    wire busy, done, match_valid;
    wire [15:0] match_x, match_y;
    wire [19:0] match_sad;

    // Instantiate DUT
    SAD_calc dut (
        .clk(clk), .rst_n(rst_n), .start(start),
        .threshold(20'd0),   // high enough threshold
        .busy(busy), .done(done),
        .match_valid(match_valid),
        .match_x(match_x), .match_y(match_y), .match_sad(match_sad)
    );

    // Clock generator
    always #5 clk = ~clk;  // 100 MHz

    initial begin
        $display("=== SAD Test Start ===");
        // Reset
        #12 rst_n = 1;
        #10 start = 1;
        #10 start = 0;

        // Watch for results
        forever begin
            @(posedge clk);
            if (match_valid)
                $display("Match at (%0d,%0d), SAD=%0d", match_x, match_y, match_sad);
            if (done) begin
                $display("=== SAD Test Done ===");
                #20 $finish;
            end
        end
    end
endmodule