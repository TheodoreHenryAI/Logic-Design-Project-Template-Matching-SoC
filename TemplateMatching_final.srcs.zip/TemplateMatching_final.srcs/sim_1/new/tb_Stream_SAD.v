`timescale 1ns / 1ps

module tb_Stream_SAD;

    // 1. Tham số (Phải khớp với Module chính)
    parameter IMG_W = 640;
    parameter TW = 40;
    parameter TH = 40;

    // 2. Tín hiệu kết nối
    reg pclk;
    reg rst_n;
    reg href;
    reg [7:0] pixel_in;

    wire match_valid;
    wire [31:0] min_sad;

    // 3. Gọi Module cần test (DUT)
    Stream_SAD #(
        .IMG_W(IMG_W),
        .TW(TW),
        .TH(TH)
    ) uut (
        .pclk(pclk),
        .rst_n(rst_n),
        .href(href),
        .pixel_in(pixel_in),
        .match_valid(match_valid),
        .min_sad(min_sad)
    );

    // 4. Tạo xung nhịp Pixel Clock (25MHz - Tương đương VGA 640x480)
    initial begin
        pclk = 0;
        forever #20 pclk = ~pclk; // Chu kỳ 40ns
    end

    // 5. Kịch bản chạy mô phỏng
    integer row, col;

    initial begin
        // --- Khởi tạo ---
        rst_n = 0;
        href = 0;
        pixel_in = 0;

        // Reset hệ thống trong 100ns
        #100;
        rst_n = 1;
        #100;

        $display("Bat dau mo phong Camera Stream...");

        // --- BẮT ĐẦU GỬI ẢNH GIẢ LẬP ---
        // Chúng ta gửi 50 dòng (Module cần 40 dòng để đầy buffer)
        for (row = 0; row < 50; row = row + 1) begin
            
            // Bắt đầu 1 dòng mới (Active Video)
            href = 1;
            
            for (col = 0; col < IMG_W; col = col + 1) begin
                
                // --- TẠO DỮ LIỆU TEST ---
                // Template trong code của bạn có giá trị = 100.
                // Ta tạo một đường kẻ dọc tại cột 100 có giá trị 100.
                // Các vị trí khác = 0.
                
                if (col == 100) 
                    pixel_in = 8'd100; // Khớp hoàn toàn với Template
                else 
                    pixel_in = 8'd0;   // Lệch hoàn toàn
                
                // Đẩy dữ liệu vào theo nhịp clock
                @(posedge pclk);
            end

            // Kết thúc 1 dòng (Horizontal Blanking)
            href = 0;
            pixel_in = 0;
            
            // Giả lập thời gian nghỉ giữa các dòng (khoảng 100 clock)
            repeat(100) @(posedge pclk);

            // In log để theo dõi tiến độ (vì chạy rất lâu)
            if (row % 10 == 0) 
                $display("Time: %t | Da gui xong dong %d", $time, row);
        end

        // Chạy thêm một chút để quan sát tín hiệu cuối cùng
        #1000;
        $display("Hoan thanh mo phong.");
        $finish;
    end

endmodule