## 1. Clock Signal (125MHz)
set_property -dict { PACKAGE_PIN H16    IOSTANDARD LVCMOS33 } [get_ports { sys_clk }];
create_clock -add -name sys_clk_pin -period 8.00 -waveform {0 4.00}  [get_ports { sys_clk }];

## 2. Reset (Switch 0)
set_property -dict { PACKAGE_PIN M20    IOSTANDARD LVCMOS33 } [get_ports { rst_n }];

## 3. LED báo hiệu (Match Valid) - Dùng LED 0
set_property -dict { PACKAGE_PIN R14    IOSTANDARD LVCMOS33 } [get_ports { match_valid_led }];

## 4. CAMERA CONTROL (PMOD JA)
# JA1 (Pin 1) -> PCLK
set_property -dict { PACKAGE_PIN Y18    IOSTANDARD LVCMOS33 } [get_ports { pclk }];
# JA2 (Pin 2) -> HREF
set_property -dict { PACKAGE_PIN Y19    IOSTANDARD LVCMOS33 } [get_ports { href }];
# JA3 (Pin 3) -> XCLK (Output ra Camera)
set_property -dict { PACKAGE_PIN Y16    IOSTANDARD LVCMOS33 } [get_ports { xclk }];

# --- CÁC CHÂN MỚI THÊM ---
# JA4 (Pin 4) -> VSYNC
set_property -dict { PACKAGE_PIN Y17    IOSTANDARD LVCMOS33 } [get_ports { vsync }];

# JA7 (Pin 7 - Hàng dưới) -> I2C SCL
set_property -dict { PACKAGE_PIN U18    IOSTANDARD LVCMOS33 } [get_ports { ov7670_scl }];
# JA8 (Pin 8 - Hàng dưới) -> I2C SDA
set_property -dict { PACKAGE_PIN U19    IOSTANDARD LVCMOS33 } [get_ports { ov7670_sda }];
# JA9 (Pin 9 - Hàng dưới) -> PWDN (Power Down)
set_property -dict { PACKAGE_PIN W18    IOSTANDARD LVCMOS33 } [get_ports { ov7670_pwdn }];
# JA10 (Pin 10 - Hàng dưới) -> RESET
set_property -dict { PACKAGE_PIN W19    IOSTANDARD LVCMOS33 } [get_ports { ov7670_rst }];

# Cho phép PCLK đi vào từ chân không chuyên dụng (Bắt buộc cho PMOD)
set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets pclk_IBUF];

## 5. CAMERA DATA (PMOD JB) - Dữ liệu ảnh D7-D0
# Map các chân JB vào pixel_in[7:0]
# JB1 (Pin 1)
set_property -dict { PACKAGE_PIN W14    IOSTANDARD LVCMOS33 } [get_ports { pixel_in[0] }];
# JB2 (Pin 2)
set_property -dict { PACKAGE_PIN Y14    IOSTANDARD LVCMOS33 } [get_ports { pixel_in[1] }];
# JB3 (Pin 3)
set_property -dict { PACKAGE_PIN T11    IOSTANDARD LVCMOS33 } [get_ports { pixel_in[2] }];
# JB4 (Pin 4)
set_property -dict { PACKAGE_PIN T10    IOSTANDARD LVCMOS33 } [get_ports { pixel_in[3] }];
# JB7 (Pin 7)
set_property -dict { PACKAGE_PIN V16    IOSTANDARD LVCMOS33 } [get_ports { pixel_in[4] }];
# JB8 (Pin 8)
set_property -dict { PACKAGE_PIN W16    IOSTANDARD LVCMOS33 } [get_ports { pixel_in[5] }];
# JB9 (Pin 9)
set_property -dict { PACKAGE_PIN V12    IOSTANDARD LVCMOS33 } [get_ports { pixel_in[6] }];
# JB10 (Pin 10)
set_property -dict { PACKAGE_PIN W13    IOSTANDARD LVCMOS33 } [get_ports { pixel_in[7] }];

## 6. HDMI TX SIGNALS (Output ra màn hình) - Arty Z7-20
# Clock Pair
set_property -dict { PACKAGE_PIN L16   IOSTANDARD TMDS_33 } [get_ports { hdmi_clk_p }];
set_property -dict { PACKAGE_PIN L17   IOSTANDARD TMDS_33 } [get_ports { hdmi_clk_n }];

# Data 0 Pair
set_property -dict { PACKAGE_PIN K17   IOSTANDARD TMDS_33 } [get_ports { hdmi_data_p[0] }];
set_property -dict { PACKAGE_PIN K18   IOSTANDARD TMDS_33 } [get_ports { hdmi_data_n[0] }];

# Data 1 Pair
set_property -dict { PACKAGE_PIN K19   IOSTANDARD TMDS_33 } [get_ports { hdmi_data_p[1] }];
set_property -dict { PACKAGE_PIN J19   IOSTANDARD TMDS_33 } [get_ports { hdmi_data_n[1] }];

# Data 2 Pair
set_property -dict { PACKAGE_PIN J18   IOSTANDARD TMDS_33 } [get_ports { hdmi_data_p[2] }];
set_property -dict { PACKAGE_PIN H18   IOSTANDARD TMDS_33 } [get_ports { hdmi_data_n[2] }];