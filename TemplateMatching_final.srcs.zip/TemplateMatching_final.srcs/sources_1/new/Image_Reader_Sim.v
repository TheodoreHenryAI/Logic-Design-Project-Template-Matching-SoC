`timescale 1ns / 1ps

module Image_Reader_Sim(
    input  wire sys_clk,    // Clock hệ thống 125MHz
    input  wire rst_n,
    
    // Output giả lập tín hiệu Camera
    output reg  pclk,       // ~25MHz
    output reg  vsync,
    output reg  href,
    output wire [18:0] rom_addr_read // Địa chỉ pixel hiện tại
);

    // 1. Tạo xung PCLK ~25MHz từ 125MHz (Chia 5)
    reg [2:0] clk_cnt = 0;
    
    always @(posedge sys_clk) begin
        if (!rst_n) begin
            clk_cnt <= 0;
            pclk <= 0;
        end else begin
            if (clk_cnt == 4) begin // Đếm 0,1,2,3,4 -> Reset
                clk_cnt <= 0;
            end else begin
                clk_cnt <= clk_cnt + 1;
            end
            
            // Tạo xung 50% duty cycle (đơn giản hóa)
            // Khi count < 2 thì low, >= 2 thì high
            pclk <= (clk_cnt >= 2);
        end
    end

    // 2. Bộ đếm tọa độ giả lập (VGA 640x480 Timing)
    reg [9:0] x = 0;
    reg [9:0] y = 0;
    
    // Thông số VGA 640x480 @ 60Hz
    localparam H_ACTIVE = 640;
    localparam H_TOTAL  = 800; // Thêm khoảng nghỉ (blanking)
    localparam V_ACTIVE = 480;
    localparam V_TOTAL  = 525;
    
    always @(posedge pclk) begin // Chạy theo pclk vừa tạo
        if (!rst_n) begin
            x <= 0;
            y <= 0;
            vsync <= 0;
            href <= 0;
        end else begin
            // Tăng x
            if (x < H_TOTAL - 1) x <= x + 1;
            else begin
                x <= 0;
                // Tăng y
                if (y < V_TOTAL - 1) y <= y + 1;
                else y <= 0;
            end
            
            // Tín hiệu HREF: Chỉ = 1 khi đang quét trong vùng ảnh 640x480
            if (x < H_ACTIVE && y < V_ACTIVE) 
                href <= 1;
            else 
                href <= 0;

            // Tín hiệu VSYNC: Báo hiệu bắt đầu khung hình mới (khi y ở cuối)
            if (y >= 490 && y < 492) // Pulse ngắn ở vùng blanking
                vsync <= 1;
            else 
                vsync <= 0;
        end
    end

    // 3. Tính địa chỉ Linear cho ROM (y * 640 + x)
    // Chỉ tính khi href = 1
    assign rom_addr_read = (href) ? (y * 640 + x) : 19'd0;

endmodule