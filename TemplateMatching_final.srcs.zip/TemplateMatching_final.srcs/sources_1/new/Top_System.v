`timescale 1ns / 1ps

module Top_System(
    input  wire sys_clk,      // 125MHz
    input  wire rst_n,
    
    // HDMI Output
    output wire [2:0] hdmi_data_p, hdmi_data_n,
    output wire hdmi_clk_p, hdmi_clk_n,
    
    // LED Báo hiệu
    output wire match_valid_led
);

    // -----------------------------------------------------------
    // 1. FAKE CAMERA (Tạo tín hiệu quét ảnh giả lập)
    // -----------------------------------------------------------
    wire sim_pclk;
    wire sim_vsync;
    wire sim_href;
    wire [18:0] rom_addr_port_a; // Địa chỉ đọc cho SAD
    
    Image_Reader_Sim fake_cam (
        .sys_clk(sys_clk),
        .rst_n(rst_n),
        .pclk(sim_pclk),
        .vsync(sim_vsync),
        .href(sim_href),
        .rom_addr_read(rom_addr_port_a)
    );

    // -----------------------------------------------------------
    // 2. DUAL PORT ROM (Chứa ảnh)
    // -----------------------------------------------------------
    wire [7:0] pixel_from_rom_a; // Pixel ra Port A -> Vào SAD
    wire [7:0] pixel_from_rom_b; // Pixel ra Port B -> Vào HDMI
    wire [18:0] rom_addr_port_b; // Địa chỉ đọc từ HDMI

    rom_image rom_inst (
        // PORT A: Nối với Fake Camera -> Đẩy vào SAD Core
        .clka(sys_clk),        // Dùng clock hệ thống cho ổn định
        .addra(rom_addr_port_a),
        .douta(pixel_from_rom_a),
        
        // PORT B: Nối với HDMI Display -> Để hiển thị
        .clkb(sys_clk),
        .addrb(rom_addr_port_b),
        .doutb(pixel_from_rom_b)
    );
    
    // -----------------------------------------------------------
    // 3. THUẬT TOÁN SAD (Template Matching)
    // -----------------------------------------------------------
    wire sad_match_found;
    
    // Bộ đếm tọa độ chạy song song để biết vị trí Match
    // (Vì sim_href chạy trước 1 nhịp so với pixel từ ROM, nhưng chấp nhận được)
    reg [9:0] scan_x, scan_y;
    always @(posedge sim_pclk) begin
        if (sim_vsync) begin scan_x <= 0; scan_y <= 0; end
        else if (sim_href) begin
             if (scan_x < 639) scan_x <= scan_x + 1;
             else begin scan_x <= 0; scan_y <= scan_y + 1; end
        end
    end

    Stream_SAD #(
        .IMG_W(640), 
        .TH(40), 
        .TW(40)
    ) processing_core (
        .pclk(sim_pclk),        
        .rst_n(rst_n),
        .href(sim_href),
        .pixel_in(pixel_from_rom_a), // <--- Dữ liệu từ ROM
        .match_valid(sad_match_found), 
        .min_sad()         
    );
    
    // Lưu tọa độ kết quả
    reg [15:0] found_x = 0;
    reg [15:0] found_y = 0;
    reg found_valid = 0;

    always @(posedge sim_pclk) begin
        if (!rst_n) begin
            found_valid <= 0;
        end else if (sad_match_found) begin
            // Trừ 40 pixel offset để vẽ khung bao đúng vào vật thể
            found_x <= (scan_x > 40) ? (scan_x - 40) : 0;
            found_y <= (scan_y > 40) ? (scan_y - 40) : 0;
            found_valid <= 1;
        end
    end

    assign match_valid_led = found_valid;

    // -----------------------------------------------------------
    // 4. HIỂN THỊ HDMI
    // -----------------------------------------------------------
    HDMI_Display display_core (
        .sys_clk(sys_clk),
        .rst_n(rst_n),
        
        // Input: Dữ liệu ảnh từ ROM Port B
        .pixel_val(pixel_from_rom_b),
        .read_addr(rom_addr_port_b), // HDMI yêu cầu địa chỉ -> ROM Port B trả lời
        
        // Input: Kết quả từ SAD để vẽ khung đỏ
        .match_valid(found_valid),
        .match_x(found_x),
        .match_y(found_y),
        
        // Output vật lý
        .hdmi_data_p(hdmi_data_p), .hdmi_data_n(hdmi_data_n),
        .hdmi_clk_p(hdmi_clk_p),   .hdmi_clk_n(hdmi_clk_n)
    );

endmodule