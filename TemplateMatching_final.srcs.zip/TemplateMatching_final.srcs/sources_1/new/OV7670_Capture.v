`timescale 1ns / 1ps

module OV7670_Capture (
    input wire pclk,
    input wire vsync,
    input wire href,
    input wire [7:0] d,       // Dữ liệu từ camera
    output reg [18:0] addr,   // Địa chỉ ghi RAM
    output reg [7:0] dout,    // Dữ liệu Pixel (Grayscale)
    output reg we             // Write Enable
);

    reg [1:0] fsm_state = 0;
    reg latch_byte = 0;       // Biến xác định byte chẵn/lẻ

    always @(posedge pclk) begin
        if (vsync) begin
            addr <= 0;
            latch_byte <= 0;
            we <= 0;
        end else if (href) begin
            // OV7670 YUV422: Byte 1 = Y, Byte 2 = U/V
            // Ta chỉ muốn lấy Byte 1 (Y - Độ sáng)
            if (latch_byte == 0) begin
                dout <= d;        // Lưu byte Y
                we <= 1;          // Cho phép ghi vào RAM
                latch_byte <= 1;  // Đánh dấu để bỏ qua byte sau
            end else begin
                we <= 0;          // Không ghi byte U/V
                latch_byte <= 0;  // Reset về trạng thái lấy byte Y
                addr <= addr + 1; // Tăng địa chỉ RAM
            end
        end else begin
            we <= 0;
        end
    end
endmodule