`timescale 1ns / 1ps

module HDMI_Display(
    input wire sys_clk,      // 125MHz (Dùng làm Clock Serial luôn)
    input wire rst_n,
    
    // Kết nối Frame Buffer (Đọc ảnh)
    input wire [7:0] pixel_val, // Giá trị xám từ RAM
    output wire [18:0] read_addr,
    
    // Kết quả tìm kiếm (Vẽ khung)
    input wire match_valid,
    input wire [15:0] match_x,
    input wire [15:0] match_y,
    
    // Chân HDMI ra board
    output wire [2:0] hdmi_data_p,
    output wire [2:0] hdmi_data_n,
    output wire hdmi_clk_p,
    output wire hdmi_clk_n
);

    // 1. TẠO PIXEL CLOCK (25MHz)
    // Arty Z7 sys_clk = 125MHz. Chia 5 sẽ ra 25MHz.

    
    reg [2:0] cnt_div;
    reg clk_pixel;
    
    always @(posedge sys_clk) begin
        if (cnt_div == 4) begin
            cnt_div <= 0;
            clk_pixel <= 1; // Tạo xung enable cho logic (hoặc làm clock)
        end else begin
            cnt_div <= cnt_div + 1;
            clk_pixel <= 0; 
        end
    end
    
    // LƯU Ý: Để OSERDES chạy đúng, ta cần clock thực sự. 
    // Vì hạn chế không dùng IP, ta dùng BUFR để chia clock là an toàn nhất.
    // (Nếu Vivado báo lỗi, bạn buộc phải dùng Clock Wizard IP để tạo 25MHz từ 125MHz).
    // Ở đây mình giả định bạn dùng BUFR hoặc IP Clock Wizard.
    // Dưới đây là cách gọi logic VGA chạy theo enable để đồng bộ 125MHz.
    
    wire vga_en = (cnt_div == 4); // Enable mỗi 5 chu kỳ
    
    // 2. VGA CONTROLLER (Logic tính tọa độ)
    wire hsync, vsync, active;
    wire [9:0] sx, sy;
    
    VGA_Controller vga_inst (
        .pixel_clk(sys_clk), // Chạy clock nhanh nhưng dùng enable
        .clk_en(vga_en),     // <--- Cần sửa nhẹ VGA_Controller để có chân enable
        .rst_n(rst_n),
        .hsync(hsync), .vsync(vsync), .active_video(active),
        .x_pos(sx), .y_pos(sy)
    );
    
    assign read_addr = sy * 640 + sx;

    // 3. LOGIC TRỘN MÀU (COLOR MIXER)
    reg [7:0] red, green, blue;
    localparam BOX_SIZE = 40;
    
    always @(posedge sys_clk) begin
        if (vga_en) begin
            if (active) begin
                // Logic vẽ khung đỏ
                if (match_valid && (
                    ((sx >= match_x && sx <= match_x + BOX_SIZE) && (sy == match_y || sy == match_y + BOX_SIZE)) ||
                    ((sy >= match_y && sy <= match_y + BOX_SIZE) && (sx == match_x || sx == match_x + BOX_SIZE))
                   )) 
                begin
                    red <= 255; green <= 0; blue <= 0;
                end else begin
                    // Ảnh Grayscale: R = G = B
                    red <= pixel_val; green <= pixel_val; blue <= pixel_val;
                end
            end else begin
                red <= 0; green <= 0; blue <= 0;
            end
        end
    end

    // 4. TMDS ENCODERS (Dùng module của bạn)
    wire [9:0] tmds_r, tmds_g, tmds_b;
    
    TMDS_encoder enc_b (.clk(sys_clk), .CD({vsync, hsync}), .VD(blue),  .VDE(active), .TMDS(tmds_b)); // Blue mang sync
    TMDS_encoder enc_g (.clk(sys_clk), .CD(2'b00),          .VD(green), .VDE(active), .TMDS(tmds_g));
    TMDS_encoder enc_r (.clk(sys_clk), .CD(2'b00),          .VD(red),   .VDE(active), .TMDS(tmds_r));

    // *Lưu ý*: Encoder của bạn cần chạy ở 25MHz hoặc dùng enable. 
    // Nếu encoder của bạn chạy theo clock, hãy nối clock enable vào nó.

    // 5. SERIALIZERS (Đẩy ra chân HDMI)
    // Cần tạo clock 25MHz thực sự cho cổng CLKDIV của OSERDES
    // Cách "chữa cháy" không dùng Clock Wizard: Dùng BUFR
    wire clk_pixel_slow;
    BUFR #(.BUFR_DIVIDE("5")) clk_div_inst (.I(sys_clk), .O(clk_pixel_slow), .CE(1'b1), .CLR(1'b0));

    HDMI_Serializer ser_b (.clk_pixel(clk_pixel_slow), .clk_5x(sys_clk), .rst(!rst_n), .tmds_data(tmds_b), .pin_p(hdmi_data_p[0]), .pin_n(hdmi_data_n[0]));
    HDMI_Serializer ser_g (.clk_pixel(clk_pixel_slow), .clk_5x(sys_clk), .rst(!rst_n), .tmds_data(tmds_g), .pin_p(hdmi_data_p[1]), .pin_n(hdmi_data_n[1]));
    HDMI_Serializer ser_r (.clk_pixel(clk_pixel_slow), .clk_5x(sys_clk), .rst(!rst_n), .tmds_data(tmds_r), .pin_p(hdmi_data_p[2]), .pin_n(hdmi_data_n[2]));
    
    // Kênh Clock (Gửi pattern 1111100000 liên tục để tạo xung clock)
    HDMI_Serializer ser_c (.clk_pixel(clk_pixel_slow), .clk_5x(sys_clk), .rst(!rst_n), .tmds_data(10'b1111100000), .pin_p(hdmi_clk_p), .pin_n(hdmi_clk_n));

endmodule