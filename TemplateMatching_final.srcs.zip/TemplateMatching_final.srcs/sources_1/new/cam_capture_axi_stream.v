`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/31/2025 09:22:53 PM
// Design Name: 
// Module Name: cam_capture_axi_stream
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module cam_capture_axi_stream #(
    parameter FRAME_WIDTH  = 640,
    parameter FRAME_HEIGHT = 480
)(
    // ===== Camera interface =====
    input  wire        pclk,       // Pixel clock
    input  wire        vsync,      // Frame sync
    input  wire        href,       // Line valid
    input  wire [7:0]  cam_d,      // Camera data

    // ===== AXI clock domain =====
    input  wire        sys_clk,
    input  wire        sys_rst_n,

    // ===== AXI Stream output (to AXI DMA S2MM) =====
    output wire [31:0] m_axis_tdata,
    output wire        m_axis_tvalid,
    input  wire        m_axis_tready,
    output wire        m_axis_tlast
);

    // ============================================================
    // Domain PCLK: Pixel Capture and Packing
    // ============================================================
    reg [1:0]  pack_cnt;
    reg [31:0] pack_reg;
    reg        fifo_wen;
    reg [31:0] fifo_din;

    reg        vsync_d, frame_start, frame_end;

    // Detect rising edge of VSYNC -> start of new frame
    always @(posedge pclk) begin
        vsync_d <= vsync;
        frame_start <= (!vsync_d && vsync);
        frame_end   <= (vsync_d && !vsync);
    end

    always @(posedge pclk) begin
        fifo_wen <= 0;
        if (href) begin
            pack_reg <= {pack_reg[23:0], cam_d};
            pack_cnt <= pack_cnt + 1;
            if (pack_cnt == 2'b11) begin
                fifo_wen <= 1;
                fifo_din <= {pack_reg[23:0], cam_d};
                pack_cnt <= 0;
            end
        end
        else if (frame_start) begin
            pack_cnt <= 0;
        end
    end

    // ============================================================
    // Async FIFO between PCLK and SYS_CLK
    // ============================================================
    wire [31:0] fifo_dout;
    wire        fifo_full;
    wire        fifo_empty;
    reg         fifo_rd_en;

    fifo_async_32x4096 u_fifo (
        .wr_clk (pclk),
        .rd_clk (sys_clk),
        .rst    (!sys_rst_n),
        .din    (fifo_din),
        .wr_en  (fifo_wen && !fifo_full),
        .rd_en  (fifo_rd_en && !fifo_empty),
        .dout   (fifo_dout),
        .full   (fifo_full),
        .empty  (fifo_empty)
    );

    // ============================================================
    // SYS_CLK domain: AXIS interface to DMA
    // ============================================================
    reg [31:0] axis_data_reg;
    reg        axis_valid_reg;
    reg        tlast_reg;

    reg [1:0]  vsync_meta;
    wire       vsync_sys, frame_end_sys;

    // Synchronize vsync to sys_clk
    always @(posedge sys_clk) vsync_meta <= {vsync_meta[0], vsync};
    assign vsync_sys     = vsync_meta[1];
    assign frame_end_sys = (vsync_meta[0] && !vsync_meta[1]); // falling edge

    always @(posedge sys_clk) begin
        if (!sys_rst_n) begin
            fifo_rd_en     <= 0;
            axis_data_reg  <= 0;
            axis_valid_reg <= 0;
            tlast_reg      <= 0;
        end else begin
            fifo_rd_en     <= 0;
            axis_valid_reg <= 0;
            tlast_reg      <= 0;

            if (!fifo_empty && m_axis_tready) begin
                fifo_rd_en     <= 1;
                axis_data_reg  <= fifo_dout;
                axis_valid_reg <= 1;
            end

            if (frame_end_sys) begin
                tlast_reg <= 1; // signal end-of-frame
            end
        end
    end

    assign m_axis_tdata  = axis_data_reg;
    assign m_axis_tvalid = axis_valid_reg;
    assign m_axis_tlast  = tlast_reg;

endmodule

