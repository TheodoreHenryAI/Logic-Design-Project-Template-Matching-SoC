`timescale 1ns / 1ps

module Frame_Buffer (
    // Port A: Ghi dữ liệu (Dành cho Camera OV7670)
    input wire clka,            // Clock ghi (PCLK từ camera)
    input wire wea,             // Tín hiệu cho phép ghi (Write Enable)
    input wire [18:0] addra,    // Địa chỉ ghi (Pixel index: y*640 + x)
    input wire [7:0]  dina,     // Dữ liệu pixel vào (Grayscale 8-bit)
    
    // Port B: Đọc dữ liệu (Dành cho HDMI Display)
    input wire clkb,            // Clock đọc (System Clock 125MHz)
    input wire [18:0] addrb,    // Địa chỉ đọc
    output reg [7:0]  doutb     // Dữ liệu pixel ra
);

    // Khai báo mảng nhớ lớn: 640 x 480 = 307,200 bytes
    // (* ram_style = "block" *) giúp Vivado hiểu đây là Block RAM (BRAM) của FPGA
    // thay vì dùng thanh ghi (LUT) sẽ làm tốn tài nguyên logic.
    
    (* ram_style = "block" *) reg [7:0] ram [0:307199];

    // Logic Ghi (Port A)
    always @(posedge clka) begin
        if (wea) begin
            ram[addra] <= dina;
        end
    end

    // Logic Đọc (Port B)
    always @(posedge clkb) begin
        doutb <= ram[addrb];
    end

endmodule