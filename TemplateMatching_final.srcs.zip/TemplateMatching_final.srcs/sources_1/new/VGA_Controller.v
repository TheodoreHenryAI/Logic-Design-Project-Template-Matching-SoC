`timescale 1ns / 1ps

module VGA_Controller (
    input wire pixel_clk,     // Clock đầu vào (Ví dụ 125MHz)
    input wire clk_en,        // Tín hiệu cho phép chạy (Enable) để giả lập 25MHz
    input wire rst_n,
    
    output wire hsync,
    output wire vsync,
    output wire active_video, // =1 khi đang ở vùng hiển thị ảnh
    output reg [9:0] x_pos,   // Tọa độ X hiện tại (0-639)
    output reg [9:0] y_pos    // Tọa độ Y hiện tại (0-479)
);

    // Thông số VGA 640x480 @ 60Hz
    localparam H_DT = 640; // Display Time
    localparam H_FP = 16;  // Front Porch
    localparam H_PW = 96;  // Pulse Width
    localparam H_BP = 48;  // Back Porch
    localparam H_TOTAL = H_DT + H_FP + H_PW + H_BP; // 800

    localparam V_DT = 480;
    localparam V_FP = 10;
    localparam V_PW = 2;
    localparam V_BP = 33;
    localparam V_TOTAL = V_DT + V_FP + V_PW + V_BP; // 525

    reg [9:0] h_cnt;
    reg [9:0] v_cnt;

    // Bộ đếm chạy theo pixel_clk nhưng chỉ tăng khi có clk_en
    always @(posedge pixel_clk) begin
        if (!rst_n) begin
            h_cnt <= 0;
            v_cnt <= 0;
        end else if (clk_en) begin // <--- QUAN TRỌNG: Chỉ đếm khi Enable = 1
            if (h_cnt < H_TOTAL - 1) begin
                h_cnt <= h_cnt + 1;
            end else begin
                h_cnt <= 0;
                if (v_cnt < V_TOTAL - 1) v_cnt <= v_cnt + 1;
                else v_cnt <= 0;
            end
        end
    end

    // Tạo xung đồng bộ (Low active)
    assign hsync = ~(h_cnt >= (H_DT + H_FP) && h_cnt < (H_DT + H_FP + H_PW));
    assign vsync = ~(v_cnt >= (V_DT + V_FP) && v_cnt < (V_DT + V_FP + V_PW));

    // Vùng hiển thị (Active Video)
    assign active_video = (h_cnt < H_DT) && (v_cnt < V_DT);

    // Xuất tọa độ
    always @(*) begin
        x_pos = (h_cnt < H_DT) ? h_cnt : 10'd0;
        y_pos = (v_cnt < V_DT) ? v_cnt : 10'd0;
    end

endmodule