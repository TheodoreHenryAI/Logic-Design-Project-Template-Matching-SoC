`timescale 1ns / 1ps

module HDMI_Serializer(
    input  wire clk_pixel,   // 25MHz (Dùng để đồng bộ load)
    input  wire clk_5x,      // 125MHz (Clock đẩy dữ liệu)
    input  wire rst,
    input  wire [9:0] tmds_data, // Dữ liệu 10-bit song song
    output wire pin_p,       // Chân dương HDMI
    output wire pin_n        // Chân âm HDMI
);

    reg [9:0] shift_reg = 0;
    reg [2:0] cycle_cnt = 0;

    // Bộ đếm Mod-5 để xác định chu kỳ nạp dữ liệu (125MHz / 5 = 25MHz)
    always @(posedge clk_5x) begin
        if (rst) begin
            cycle_cnt <= 0;
            shift_reg <= 0;
        end else begin
            if (cycle_cnt == 4) begin
                cycle_cnt <= 0;
                shift_reg <= tmds_data; // Nạp 10 bit mới (Load)
            end else begin
                cycle_cnt <= cycle_cnt + 1;
                shift_reg <= {2'b00, shift_reg[9:2]}; // Dịch phải 2 bit
            end
        end
    end

    // ODDR: Truyền 2 bit mỗi chu kỳ 125MHz (Tổng 10 bit trong 5 chu kỳ)
    // Bit 0 ở sườn lên, Bit 1 ở sườn xuống
    wire ddr_out;
    
    ODDR #(
        .DDR_CLK_EDGE("SAME_EDGE"), 
        .INIT(1'b0),
        .SRTYPE("SYNC")
    ) oddr_inst (
        .Q(ddr_out),
        .C(clk_5x),
        .CE(1'b1),
        .D1(shift_reg[0]), // Bit LSB
        .D2(shift_reg[1]), // Bit tiếp theo
        .R(rst),
        .S(1'b0)
    );

    // Bộ đệm vi sai ra chân vật lý
    OBUFDS obuf_inst (
        .I(ddr_out), 
        .O(pin_p), 
        .OB(pin_n)
    );

endmodule