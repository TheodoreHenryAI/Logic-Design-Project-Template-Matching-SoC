`timescale 1ns / 1ps

module Simple_Line_RAM # (
    // Đổi tên parameter thành WIDTH để khớp với Stream_SAD gọi .WIDTH(IMG_W)
    parameter WIDTH = 640,      // Chiều rộng ảnh (Depth của RAM)
    parameter DATA_WIDTH = 8    // Độ rộng pixel
) (
    input wire clk,
    input wire we,              // Tín hiệu valid/enable (nối với href)
    input wire [DATA_WIDTH-1:0] din,
    output reg [DATA_WIDTH-1:0] dout
);

    // Tính toán số bit cần thiết cho địa chỉ dựa trên WIDTH
    // Ví dụ: 640 cần 10 bit (2^10 = 1024)
    localparam ADDR_BITS = $clog2(WIDTH);

    // Khai báo bộ nhớ Block RAM
    (* ram_style = "block" *) reg [DATA_WIDTH-1:0] mem [0:WIDTH-1];
    
    // Biến đếm địa chỉ nội bộ (Con trỏ chạy dọc dòng)
    reg [ADDR_BITS-1:0] ptr;

    initial begin
        ptr = 0;
    end

    always @(posedge clk) begin
        if (we) begin
            // 1. Đọc dữ liệu cũ tại vị trí hiện tại ra (Dòng cũ)
            dout <= mem[ptr];
            
            // 2. Ghi dữ liệu mới vào vị trí đó (Dòng mới đè lên để dùng cho vòng sau)
            mem[ptr] <= din;
            
            // 3. Tăng con trỏ, nếu hết dòng thì quay về 0
            if (ptr == WIDTH - 1)
                ptr <= 0;
            else
                ptr <= ptr + 1;
        end
    end

endmodule