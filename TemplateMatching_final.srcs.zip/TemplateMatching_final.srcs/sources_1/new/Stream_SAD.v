`timescale 1ns / 1ps

module Stream_SAD #(
    parameter IMG_W = 640,      // Chiều rộng ảnh
    parameter TW = 180,          // Chiều rộng Template
    parameter TH = 180,          // Chiều cao Template
    parameter THRESHOLD = 10000  // Ngưỡng so sánh (Càng nhỏ càng gắt)
)(
    input  wire pclk,           // Pixel Clock (25MHz)
    input  wire rst_n,
    input  wire href,           // Tín hiệu dữ liệu hợp lệ
    input  wire [7:0] pixel_in, // Dữ liệu từ Camera/ROM
    
    output reg match_valid,     // = 1 khi tìm thấy ảnh
    output reg [31:0] min_sad   // Giá trị độ lệch nhỏ nhất (để debug)
);

    // =========================================================
    // 1. CHUỖI LINE BUFFER (Lưu 39 dòng trước đó)
    // =========================================================
    wire [7:0] t_data [0:TH-1]; // Mảng chứa cột dọc 40 pixel
    
    assign t_data[0] = pixel_in; // Dòng hiện tại là dòng 0
    
    genvar i;
    generate
        for (i = 0; i < TH-1; i = i + 1) begin : BUFFERS
            Simple_Line_RAM #(.WIDTH(IMG_W)) ram_inst (
                .clk(pclk),
                .we(href),       
                .din(t_data[i]),    // Vào từ dòng i
                .dout(t_data[i+1])  // Ra xuống dòng i+1
            );
        end
    endgenerate

    // =========================================================
    // 2. NẠP TEMPLATE TỪ FILE .TXT
    // =========================================================
    // Dùng mảng 1 chiều để dễ dùng $readmemh
    (* ram_style = "block" *) reg [7:0] template_mem [0 : (TW*TH)-1];

    initial begin
        // QUAN TRỌNG: File template.txt phải nằm trong project
        $readmemh("template.txt", template_mem);
    end

    // =========================================================
    // 3. QUẢN LÝ TỌA ĐỘ (X, Y COUNTER)
    // =========================================================
    reg [9:0] x_cnt;
    reg [9:0] y_cnt;

    always @(posedge pclk) begin
        if (!rst_n) begin
            x_cnt <= 0;
            y_cnt <= 0;
        end else if (href) begin
            if (x_cnt < IMG_W - 1) begin
                x_cnt <= x_cnt + 1;
            end else begin
                x_cnt <= 0;
                if (y_cnt < 479) y_cnt <= y_cnt + 1; // Giả sử cao 480
                else y_cnt <= 0;
            end
        end else begin
            x_cnt <= 0; // Reset x khi hết dòng (hết href)
        end
    end

    // =========================================================
    // 4. TÍNH COLUMN SAD (ĐỘ LỆCH CỦA CỘT DỌC)
    // =========================================================
    
    reg [15:0] current_col_diff;
    reg [9:0]  k;
    reg [7:0]  pixel_img, pixel_tpl;
    reg [15:0] diff_abs;
    reg [15:0] col_sad_sum; // Tổng độ lệch của 1 cột

    // Xác định cột nào của Template cần lôi ra so sánh
    wire [9:0] template_col_idx = (x_cnt >= TW) ? (x_cnt % TW) : x_cnt;

    always @(*) begin
        col_sad_sum = 0;
        // Vòng lặp tính tổng chênh lệch của 40 cặp pixel dọc
        for (k = 0; k < TH; k = k + 1) begin
            pixel_img = t_data[k];
            // Lấy pixel từ mảng template (k: dòng, template_col_idx: cột)
            pixel_tpl = template_mem[k * TW + template_col_idx];
            
            if (pixel_img > pixel_tpl) diff_abs = pixel_img - pixel_tpl;
            else                       diff_abs = pixel_tpl - pixel_img;
            
            col_sad_sum = col_sad_sum + diff_abs;
        end
    end

    // =========================================================
    // 5. CỘNG DỒN CỬA SỔ (WINDOW ACCUMULATOR)
    // =========================================================
    
    reg [31:0] window_sad;
    reg [15:0] sad_history [0:TW-1]; // Lưu lịch sử 40 cột trước
    reg [5:0]  ptr;
    
    always @(posedge pclk) begin
        if (!rst_n) begin
            window_sad <= 0;
            match_valid <= 0;
            min_sad <= 32'hFFFFFFFF;
            ptr <= 0;
             //1. Reset history loop
        end else if (href) begin
            // (Logic Moving Average)
            window_sad <= window_sad + col_sad_sum - sad_history[ptr];
            
            // 2. Lưu cột mới vào lịch sử
            sad_history[ptr] <= col_sad_sum;
            
            // 3. Tăng con trỏ vòng tròn (0..39)
            if (ptr == TW-1) ptr <= 0;
            else ptr <= ptr + 1;

            // ============================================
            // 6. KIỂM TRA KẾT QUẢ
            // ============================================
            // Chỉ kiểm tra khi đã quét đủ 1 ô cửa sổ
            if (x_cnt >= TW && y_cnt >= TH) begin
                // Nếu tổng sai số nhỏ hơn ngưỡng -> TÌM THẤY
                if (window_sad < THRESHOLD) begin 
                    match_valid <= 1;
                    min_sad <= window_sad;
                end else begin
                    match_valid <= 0;
                end
            end
        end else begin
            // Reset khi hết dòng để tránh cộng dồn sai dòng sau
            window_sad <= 0;
            ptr <= 0;
            // Clear history
        end
    end

endmodule

// =========================================================
// MODULE CON: RAM ĐỆM DÒNG ĐƠN GIẢN
// =========================================================
module Simple_Line_RAM #(parameter WIDTH = 640) (
    input wire clk,
    input wire we,
    input wire [7:0] din,
    output wire [7:0] dout
);
    // Dùng Distributed RAM (LUT RAM) cho tiết kiệm Block RAM
    (* ram_style = "distributed" *) reg [7:0] memory [0:WIDTH-1];
    reg [9:0] ptr = 0;
    
    // Logic FIFO 1 dòng
    always @(posedge clk) begin
        if (we) begin
            memory[ptr] <= din;     // Ghi pixel mới vào
            
            if (ptr == WIDTH-1) ptr <= 0;
            else ptr <= ptr + 1;
        end
    end
    
    // Đọc dữ liệu cũ tại vị trí sắp ghi (tức là dữ liệu của dòng trước tại cùng cột X)
    assign dout = memory[ptr]; 

endmodule