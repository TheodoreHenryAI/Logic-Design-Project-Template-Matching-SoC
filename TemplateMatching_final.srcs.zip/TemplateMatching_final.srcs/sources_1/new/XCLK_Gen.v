`timescale 1ns / 1ps

module XCLK_Gen(
    input  wire clk_in,   // Input: 125 MHz từ bo mạch Arty Z7
    output reg  xclk      // Output: 25 MHz
);

    reg [2:0] counter = 0;

    // Logic chia 5: 125MHz / 5 = 25MHz
    // Chu kỳ đếm: 0, 1, 2, 3, 4 (Tổng 5 nhịp)
    always @(posedge clk_in) begin
        if (counter == 4) begin
            counter <= 0;
        end else begin
            counter <= counter + 1;
        end
        
        // Tạo xung vuông (Duty cycle 40% - 2 High / 3 Low)
        // Camera OV7670 chấp nhận duty cycle không cần chuẩn 50%
        xclk <= (counter < 2) ? 1'b1 : 1'b0;
    end

endmodule